<?php
echo '<a href="#"><img class="logo" src="images/logo.png" alt="KOKO Logo"/></a>';
?>