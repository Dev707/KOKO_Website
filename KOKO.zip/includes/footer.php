<div class="footer" style="margin-top: 20px;">
<?php
$validator = "https://jigsaw.w3.org/css-validator/";
$valImg = "images/validator.png";
$valImg2 = "images/validator2.png";
$validator2 = "http://www.w3.org/Icons/valid-xhtml10";
echo "<a href='$validator'><img src='$valImg' width='90' height='50' alt='validator'/></a>";
echo "<a href='$validator2'><img src=' $valImg2'  width='90' height='50' alt='validator'/></a>";
echo "<a style='display:block; padding:0px;'>© KSG.sa</a>";
?>
</div>